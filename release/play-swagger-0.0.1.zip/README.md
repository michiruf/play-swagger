# play-swagger
Playframework 1.3 module to integrate swagger
